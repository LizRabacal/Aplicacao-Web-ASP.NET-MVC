-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: empresarabanete
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `produto`
--

DROP TABLE IF EXISTS `produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto` (
  `ID_PRODUTO` int NOT NULL AUTO_INCREMENT,
  `NOME_PRODUTO` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `DESCRICAO` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `PRECO` float DEFAULT NULL,
  `ESTOQUE` int DEFAULT NULL,
  `IMAGEM` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`ID_PRODUTO`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produto`
--

LOCK TABLES `produto` WRITE;
/*!40000 ALTER TABLE `produto` DISABLE KEYS */;
INSERT INTO `produto` VALUES (1,'Samsung Galaxy S21','Smartphone avançado da Samsung com câmera de alta resolução',999.99,50,'https://a-static.mlcdn.com.br/800x560/smartphone-samsung-galaxy-s21-fe-128gb-preto-5g-octa-core-6gb-ram-64-cam-tripla-selfie-32mp-dual-chip/magazineluiza/237062800/8db0da74d5d097cbfa2e94ad18f2c7fd.jpg'),(2,'iPhone 13 Pro','Smartphone premium da Apple com desempenho excepcional',1299.99,30,'https://m.media-amazon.com/images/I/41K0G9FgD4L._AC_SX679_.jpg'),(3,'Samsung 4K QLED TV','Televisão 4K da Samsung com tecnologia QLED para qualidade de imagem superior',1499.99,15,'https://m.media-amazon.com/images/I/91lGufYy6GL.__AC_SY300_SX300_QL70_ML2_.jpg'),(4,'OnePlus 9','Flagship killer with top-notch performance',899.99,40,'https://m.media-amazon.com/images/I/51ZUPFFu36L.__AC_SX300_SY300_QL70_ML2_.jpg'),(5,'Google Pixel 6','Innovative camera features and pure Android experience',799.99,25,'https://static-catalog.tiendamia.com/marketplace_images/production/product_100066_mirakl_image_4_medium.jpg'),(6,'Xiaomi Mi 11','Powerful smartphone with a sleek design',749.99,35,'https://i.ebayimg.com/images/g/nsEAAOSwz2Vf8~7p/s-l960.png'),(7,'Sony Xperia 5 III','Compact phone with advanced camera capabilities',1099.99,20,'https://i.ebayimg.com/images/g/7QsAAOSwQPthgPsV/s-l960.jpg'),(8,'Huawei P40 Pro','Leica quad-camera system for stunning photography',1099.99,15,'https://i.ebayimg.com/images/g/IgcAAOSwIBJejacc/s-l960.png'),(9,'LG Velvet','Stylish design with a dual-screen accessory option',599.99,30,'https://i.ebayimg.com/images/g/~Q0AAOSw3ztkFH2J/s-l960.jpg'),(10,'Motorola Edge+','High-performance device with a large battery',799.99,28,'https://m.media-amazon.com/images/I/51QcSC+yEML._AC_SY300_SX300_.jpg'),(11,'Nokia 9 PureView','Unique penta-camera setup for photography enthusiasts',899.99,22,'https://i.zst.com.br/thumbs/1/2b/13/-1132123267.jpg'),(12,'Asus ROG Phone 6','Gaming-oriented smartphone with top-notch specs',1299.99,18,'https://i.ebayimg.com/images/g/bSUAAOSwzg5ix~3a/s-l960.png'),(13,'Lenovo Legion Phone Duel 2','Designed for mobile gaming with a dual-turbo fan system',1199.99,12,'https://m.media-amazon.com/images/I/71J2yC-+FsS._AC_SX679_.jpg');
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-17 22:39:35

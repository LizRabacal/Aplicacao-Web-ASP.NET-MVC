-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: empresarabanete
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aspnetusers`
--

DROP TABLE IF EXISTS `aspnetusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aspnetusers` (
  `Id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ID_CLIENTE` int NOT NULL,
  `NOME_CLI` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `TELEFONE` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ENDERECO` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `UserName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `NormalizedUserName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Email` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `NormalizedEmail` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `EmailConfirmed` tinyint(1) NOT NULL,
  `PasswordHash` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `SecurityStamp` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ConcurrencyStamp` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PhoneNumber` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PhoneNumberConfirmed` tinyint(1) NOT NULL,
  `TwoFactorEnabled` tinyint(1) NOT NULL,
  `LockoutEnd` datetime(6) DEFAULT NULL,
  `LockoutEnabled` tinyint(1) NOT NULL,
  `AccessFailedCount` int NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UserNameIndex` (`NormalizedUserName`),
  KEY `EmailIndex` (`NormalizedEmail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aspnetusers`
--

LOCK TABLES `aspnetusers` WRITE;
/*!40000 ALTER TABLE `aspnetusers` DISABLE KEYS */;
INSERT INTO `aspnetusers` VALUES ('13206403-0e73-479b-aafb-5b95eccc277e',0,'Liz Oliveira Souza Rabaçal','71992075679','dvsfgverf','geo@gmail.com','GEO@GMAIL.COM','geo@gmail.com','GEO@GMAIL.COM',0,'AQAAAAIAAYagAAAAENluDPlyXnrBrG5Y5KMAsTAI6T2xT6ug98KxuLdM18H9m1nG00vqBnCn7BCnBhbjoA==','REJT3LZEMMIKSPEKNK3V5EYMS6FKATMS','c67bdd56-6388-4be7-9a14-302031145bf7',NULL,0,0,NULL,1,0),('47d79133-1828-429f-96ae-bee270a166cc',1,'joaozinho','23','senha',NULL,NULL,'joao@gmail.com',NULL,0,'Senha@123','8f1e345d-68b7-413c-9b4c-17cded8ec3fe','58649d56-8bdd-438b-97bc-ec3f40f156bd',NULL,0,0,NULL,0,0),('554a4e8d-ac6e-4046-8541-0b52601a0488',0,'Liz Oliveira Souza Rabaçal','71992075679','gerger','liz@gmail.com','LIZ@GMAIL.COM','liz@gmail.com','LIZ@GMAIL.COM',0,'AQAAAAIAAYagAAAAEOBcmnJyQkhPwI7pCmmj6lGhALA0jRp+4OLevP2AlaW1T/cC3Ftyb+to9MB0JW7aqA==','HTKAX3ZC6PNAOR6PGU7VIRCWR26MLWFH','6f7ae65d-9735-4a8c-8bc8-edef61798bf1',NULL,0,0,NULL,1,0),('a89cc689-ded7-4af8-9b01-47bf2da125b8',0,'Liz Oliveira Souza Rabaçal','71992075679','dfarsvf','biscoito@gmail.com','BISCOITO@GMAIL.COM','biscoito@gmail.com','BISCOITO@GMAIL.COM',0,'AQAAAAIAAYagAAAAEEMBRtR9nGbbUy+SaTRUiI2na9QSKpu6YES++RXCGk3Sr/S/HfyRLIbRem/d0vGi8w==','D4MK2ZDJUVSWCAF4ZLEKTCOI7OPANG3S','e7e38ba0-a968-4db6-abb9-95a3747ef00e',NULL,0,0,NULL,1,0),('ab03750a-1641-48f1-b4d6-79a5e556b27b',0,'jao','435463','dfvdfv','jao@gmail.com','JAO@GMAIL.COM','jao@gmail.com','JAO@GMAIL.COM',0,'AQAAAAIAAYagAAAAEK7A22ArthTSNjZzTBym1He7WY6L4srabal2n7hYrjJuzqQZGK/fxiAaAKfQ0l5Iog==','HYYTNHI6RH2AMZM2YFYHUNS3VYMU7OQX','7ce72c59-dcca-466a-bd5e-d96e37896731',NULL,0,0,NULL,1,0),('cb2bf31b-6812-434d-9a9d-5865feef4af8',0,'Liz Oliveira Souza Rabaçal','71992075679','gerger','alho@gmail.com','ALHO@GMAIL.COM','alho@gmail.com','ALHO@GMAIL.COM',0,'AQAAAAIAAYagAAAAECIKGMiBTLWyZKCkkD2owCU6ATCKTAu34qVqJ121acWsSi5WKLjGvAVjpc7jaE8piw==','G7X5QSWGOA2JDVDBMTOFMMYEYJQZHLZJ','dab90096-7cd8-4a26-8395-898973d62dda',NULL,0,0,NULL,1,0),('ee90ffb6-61e7-4116-8b07-3dbf1e099609',0,'Liz Oliveira Souza Rabaçal','71992075679','rdef','pao@gmail.com','PAO@GMAIL.COM','pao@gmail.com','PAO@GMAIL.COM',0,'AQAAAAIAAYagAAAAEC+6xa3h52lr3iLXhl4fEIqDd9Ya6ChHsq8M87IKaU5LjYLtV+Sx/6iYfP7/N4OU3Q==','3SLQT5HXFVSSXQONEOZR6NMXU4XIC6R7','93f3d504-8df6-4979-901d-714078124074',NULL,0,0,NULL,1,0);
/*!40000 ALTER TABLE `aspnetusers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-17 22:39:33
